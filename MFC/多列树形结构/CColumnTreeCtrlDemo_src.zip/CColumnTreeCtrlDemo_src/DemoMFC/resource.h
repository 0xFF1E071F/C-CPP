//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DemoMFC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMOMFC_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_TREEBTNS                    131
#define IDI_ICON1                       132
#define IDI_CDROM                       132
#define IDI_ICON3                       134
#define IDI_FIXEDDISK                   134
#define IDI_ICON4                       135
#define IDI_FLOPPY                      135
#define IDI_ICON5                       136
#define IDI_HARDDISK                    136
#define IDI_ICON6                       137
#define IDI_MYCOMPUTER                  137
#define IDI_ICON7                       138
#define IDI_NETWORKPLACE                138
#define IDI_ICON8                       139
#define IDI_OVERLAY1                    139
#define IDB_BKGND                       140
#define IDC_COLUMNTREE                  1000
#define IDC_CHKICONS                    1001
#define IDC_CHKLARGRICONS               1002
#define IDC_CHKHASLINES                 1003
#define IDC_CHKHASCHKBOXES              1004
#define IDC_CHKTRACKSELECT              1005
#define IDC_CHKFULLROWSELECT            1006
#define IDC_OPTIONS                     1007
#define IDC_CHECK1                      1008
#define IDC_CHKHASBUTTONS               1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
